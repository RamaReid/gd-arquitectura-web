(() => {
  'use strict';
  const qs = s => document.querySelector(s);
  const qsa = s => [...document.querySelectorAll(s)];
  const canvas = qs('#map-canvas');
  if (!canvas) return;
  const projects = window.GD_PROJECTS || [];
  const ids = new Set(projects.map(p => p.id));
  const normalize = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  const key = 'gd.locations.v1';
  const otherKey = 'gd.other-projects.v1';
  // Ubicaciones confirmadas por el propietario, incorporadas el 2026-11-06.
  const confirmedBackup = {"version":2,"locations":{"cedahause":{"latitude":-37.340633,"longitude":-59.065418,"environment":"city","verified":true},"gadehause":{"latitude":-37.335881,"longitude":-59.103581,"environment":"city","verified":true},"markhause":{"latitude":-37.349153,"longitude":-59.134684,"environment":"city","verified":true},"donahause":{"latitude":-37.335303,"longitude":-59.098436,"environment":"city","verified":true},"jobehause":{"latitude":-37.334085,"longitude":-59.099998,"environment":"city","verified":true},"scohause":{"latitude":-37.335926,"longitude":-59.103834,"environment":"city","verified":true},"jomahause":{"latitude":-37.335228,"longitude":-59.101971,"environment":"city","verified":true},"jonohause":{"latitude":-37.336248,"longitude":-59.105769,"environment":"city","verified":true},"magahause":{"latitude":-37.337018,"longitude":-59.104079,"environment":"city","verified":true},"vidahause":{"latitude":-37.326864,"longitude":-59.097905,"environment":"city","verified":true}},"otherProjects":{"other-a409ea8e-1725-4454-9b09-c766a8918327":{"latitude":-37.33229,"longitude":-59.089794,"environment":"city","verified":true,"name":"Casas"},"other-7fa770b6-4b50-4941-a93b-a5e818515e1f":{"latitude":-37.32933274762443,"longitude":-59.09302353858948,"environment":"city","verified":true,"name":"Casas"},"other-3df424e9-9f57-4c13-8060-e4bfdc9b1e0e":{"latitude":-37.32914506154089,"longitude":-59.09314155578614,"environment":"city","verified":true,"name":"Casas"},"other-48fb0538-30e4-404e-bbc2-7f27a1a3d5f1":{"latitude":-37.3293924658254,"longitude":-59.092766046524055,"environment":"city","verified":true,"name":"Casas"},"other-8842a389-0b7e-4583-b78d-beaed5e3ea3e":{"latitude":-37.33099630832373,"longitude":-59.089289903640754,"environment":"city","verified":true,"name":"Casas"},"other-972e6f3f-d7cd-440e-b140-9f4d070d5998":{"latitude":-37.32356651849561,"longitude":-59.09494400024414,"environment":"city","verified":true,"name":"Casas"},"other-b92e2a36-0eea-4740-a277-fcc4e3c53d42":{"latitude":-37.311279679505255,"longitude":-59.11065101623536,"environment":"city","verified":true,"name":"Casas"},"other-f19374e4-97fa-42c0-8924-891f89b30bc3":{"latitude":-37.33148790475084,"longitude":-59.121164875952125,"environment":"city","verified":true,"name":"Casas"},"other-5be7db7c-72a2-46a7-a359-0a31acc4e49f":{"latitude":-37.32845078373465,"longitude":-59.119396067273755,"environment":"city","verified":true,"name":"Casas"},"other-da4f6c8d-50c0-40c7-b9c6-2683fa0b6491":{"latitude":-37.33343288351245,"longitude":-59.11579186342336,"environment":"city","verified":true,"name":"Casas"},"other-21bd352f-3aea-4a52-b303-003ee4f5d58e":{"latitude":-37.334558928654005,"longitude":-59.09991323091069,"environment":"city","verified":true,"name":"Casas"},"other-7e524d66-2529-4fbd-9a76-cca601d1cf8f":{"latitude":-37.33507076183166,"longitude":-59.100835735467626,"environment":"city","verified":true,"name":"Casas"},"other-b71b7252-3868-4844-b4ff-e4ae156f80ef":{"latitude":-37.33585556593044,"longitude":-59.09918380870286,"environment":"city","verified":true,"name":"Casas"},"other-7ef2cdae-0452-4005-af27-7de06eec9d84":{"latitude":-37.33512194495763,"longitude":-59.103517434761066,"environment":"city","verified":true,"name":"Casas"},"other-17209227-e557-430a-b426-e42a6d77bae5":{"latitude":-37.336196782546274,"longitude":-59.10298109490239,"environment":"city","verified":true,"name":"Casas"},"other-a6975f71-11f4-4336-8a48-e91fade250dd":{"latitude":-37.33667448320435,"longitude":-59.10223021910023,"environment":"city","verified":true,"name":"Casas"},"other-e24740f8-0b41-4a80-9a09-fcf78df35dbd":{"latitude":-37.33585556593044,"longitude":-59.10459011447846,"environment":"city","verified":true,"name":"Casas"},"other-947e7563-4c26-41ec-9ee5-3a2c87cd047d":{"latitude":-37.33643563325507,"longitude":-59.09909799432548,"environment":"city","verified":true,"name":"Casas"},"other-033650a9-eca1-4de2-be99-dd4d6660e8a3":{"latitude":-37.32423621548203,"longitude":-59.10697197317248,"environment":"city","verified":true,"name":"Casas"},"other-d3875448-c56a-45cd-9b7f-d2acf2bbc655":{"latitude":-37.32292231385399,"longitude":-59.10549167516249,"environment":"city","verified":true,"name":"Casas"},"other-65a86e4e-2ffc-4c8d-93d2-30ce4741e09d":{"latitude":-37.323758435940256,"longitude":-59.12448052427864,"environment":"city","verified":true,"name":"Casas"},"other-8014a3ca-5e75-4833-a2c2-ecd557cd420a":{"latitude":-37.32369018144196,"longitude":-59.126625883713395,"environment":"city","verified":true,"name":"Casas"},"other-9631bf54-acb0-427c-870e-bb25d7ee7362":{"latitude":-37.332050896225084,"longitude":-59.133085197598184,"environment":"city","verified":true,"name":"Casas"},"other-04424655-2c67-4d73-af6c-aff0b73b7599":{"latitude":-37.3359749917661,"longitude":-59.135209462282496,"environment":"city","verified":true,"name":"Casas"},"other-f62c35a7-8f27-4f1b-a3c5-c1fe4234a05f":{"latitude":-37.340427787676525,"longitude":-59.13830984141932,"environment":"city","verified":true,"name":"Casas"},"other-f1542b05-d21a-4b1b-b80a-30d5e73e0859":{"latitude":-37.34882070745369,"longitude":-59.13006059963908,"environment":"city","verified":true,"name":"Casas"},"other-32b3358f-3330-4476-9667-c0a280244c3a":{"latitude":-37.354193761324936,"longitude":-59.12559825201478,"environment":"city","verified":true,"name":"Casas"},"other-e0be0889-5be9-4752-88a6-dad03a9ee70a":{"latitude":-37.36924866703849,"longitude":-59.11259536757655,"environment":"city","verified":true,"name":"Casas"},"other-b17ea442-2c48-4f42-85c5-407340af5c66":{"latitude":-37.346274380580766,"longitude":-59.135595484258765,"environment":"city","verified":true,"name":"Casas"},"other-0715f512-9b2a-421f-b75d-8b3e66e2aae7":{"latitude":-37.348423721169866,"longitude":-59.13752630775003,"environment":"city","verified":true,"name":"Casas"},"other-c6391d10-e1b4-487d-b21a-9304427d2a6b":{"latitude":-37.3202556597511,"longitude":-59.141711357134255,"environment":"city","verified":true,"name":"Casas"},"other-32448824-c326-42df-bbc2-61afa007a814":{"latitude":-37.32065279363154,"longitude":-59.190118772592264,"environment":"city","verified":true,"name":"Casas"},"other-22b34d20-7ccd-4659-8002-2bce9d6d6163":{"latitude":-37.326401698650464,"longitude":-59.13443642335373,"environment":"city","verified":true,"name":"Casas"},"other-8087332e-9212-4bb7-9b40-11d409367e71":{"latitude":-37.336399960873976,"longitude":-59.12313004067753,"environment":"city","verified":true,"name":"Casas"},"other-c12b3c7f-2590-4f86-b78e-0084eb64d030":{"latitude":-37.33686059960057,"longitude":-59.1228940511397,"environment":"city","verified":true,"name":"Casas"},"other-9d291a10-f56e-4d63-b058-9d3c4b8042d0":{"latitude":-37.336672932312226,"longitude":-59.121692649856236,"environment":"city","verified":true,"name":"Casas"},"other-c633bcf0-9273-4b1f-a6d0-3f3605a58ff4":{"latitude":-37.34044324881826,"longitude":-59.120298166223634,"environment":"city","verified":true,"name":"Casas"},"other-74cf485d-9fc8-48fe-ae77-bb5dee65640c":{"latitude":-37.34141565268879,"longitude":-59.11525657155195,"environment":"city","verified":true,"name":"Casas"},"other-d9573c83-2a1c-4b25-a2cc-4a4486a33056":{"latitude":-37.33036021402635,"longitude":-59.112059985994165,"environment":"city","verified":true,"name":"Casas"},"other-a208414b-14f6-4f13-875c-f9c574255891":{"latitude":-37.3526757466231,"longitude":-59.14129256386596,"environment":"city","verified":true,"name":""},"other-434468d2-ef83-4640-bb51-532a47f799a0":{"latitude":-37.34118,"longitude":-59.130504,"environment":"city","verified":true,"name":""},"other-b5093f67-fd8c-4d60-ba27-1d4c48401d5b":{"latitude":-37.33636871790684,"longitude":-59.09709637894027,"environment":"city","verified":true,"name":""},"other-62bc5196-df62-47a6-8dc7-98773fd82abb":{"latitude":-37.33640283940294,"longitude":-59.10122688007915,"environment":"city","verified":true,"name":""},"other-e846b7dd-ac5b-453a-be4f-aec1eb10c4e2":{"latitude":-37.33648814307538,"longitude":-59.100883565698794,"environment":"city","verified":true,"name":""}}};
  let locations = {}, map = null, layer = null, draftMarker = null, importDraft = null, active = null;
  let otherProjects = {}, editingOther = null;
  let batchMode = false, batchPoints = [];
  let storageAvailable = true;
  let otherStorageAvailable = true;
  const markers = new Map();
  const views = {city:{center:[-37.3283,-59.1357],zoom:12},rural:{center:[-37.3283,-59.1357],zoom:9}};
  const status = message => { qs('#location-status').textContent = message; };
  const valid = item => item && item.verified === true && Number.isFinite(item.latitude) && Number.isFinite(item.longitude) && Math.abs(item.latitude) <= 90 && Math.abs(item.longitude) <= 180 && ['city','rural'].includes(item.environment);
  function decode(data) {
    if (!data || data.version !== 1 || !data.locations || typeof data.locations !== 'object' || Array.isArray(data.locations)) throw new Error('La copia no tiene el formato de ubicaciones de GD.');
    const result = {};
    for (const [id,item] of Object.entries(data.locations)) {
      if (!ids.has(id) || !valid(item)) throw new Error('La copia contiene una obra o una ubicación no válida.');
      result[id] = {latitude:item.latitude,longitude:item.longitude,environment:item.environment,verified:true};
    }
    return result;
  }
  function decodeOther(data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('La copia de otros proyectos no es válida.');
    const result = {};
    for (const [id,item] of Object.entries(data)) {
      if (!/^other-[a-zA-Z0-9-]+$/.test(id) || !valid(item) || typeof item.name !== 'string' || item.name.length > 120) throw new Error('La copia contiene otro proyecto no válido.');
      result[id] = {latitude:item.latitude,longitude:item.longitude,environment:item.environment,verified:true,name:item.name};
    }
    return result;
  }
  function decodeBackup(data) {
    if (!data || ![1,2].includes(data.version)) throw new Error('La copia no tiene el formato de ubicaciones de GD.');
    return {locations:decode({version:1,locations:data.locations}),otherProjects:data.version === 2 ? decodeOther(data.otherProjects) : null};
  }
  const confirmed = decodeBackup(confirmedBackup);
  locations = confirmed.locations;
  otherProjects = confirmed.otherProjects;
  try {
    const saved = localStorage.getItem(key);
    if (saved) locations = decode(JSON.parse(saved));
  } catch {
    storageAvailable = false;
    status('No se pudo recuperar el guardado local. Podés recuperar una copia o marcar puntos y descargarlos para conservarlos.');
  }
  try {
    const saved = localStorage.getItem(otherKey);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.version !== 1) throw new Error('Version');
      otherProjects = decodeOther(data.otherProjects);
    }
  } catch {
    otherStorageAvailable = false;
    status('No se pudo recuperar el guardado de otros proyectos. Las ubicaciones de las casas se conservan.');
  }
  function persist() {
    try {
      localStorage.setItem(key,JSON.stringify({version:1,locations}));
      storageAvailable = true;
      return true;
    } catch { storageAvailable = false; return false; }
  }
  function persistOther() {
    try {
      localStorage.setItem(otherKey,JSON.stringify({version:1,otherProjects}));
      otherStorageAvailable = true;
      return true;
    } catch { otherStorageAvailable = false; return false; }
  }
  const otherName = record => record.name || 'Otros proyectos';
  const newOtherId = () => 'other-'+(window.crypto?.randomUUID?.() || Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10));
  function otherPopup(record) {
    const el=document.createElement('div');
    const name=document.createElement('strong');name.textContent='Otros proyectos';
    const text=document.createElement('p');text.textContent=[record.name,record.environment==='city'?'Ciudad':'Campo y alrededores'].filter(Boolean).join(' · ');
    el.append(name,text);return el;
  }
  function popup(project) {
    const el = document.createElement('div');
    const name = document.createElement('strong'); name.textContent = project.name;
    const p = document.createElement('p'); p.textContent = locations[project.id].environment === 'city' ? 'Ciudad · ubicación confirmada' : 'Campo y alrededores · ubicación confirmada';
    const a = document.createElement('a'); a.href = `obras/${project.id}.html`; a.textContent = 'Recorrer la obra ↗';
    el.append(name,p,a); return el;
  }
  function render() {
    layer?.clearLayers(); markers.clear();
    const term = normalize(qs('#map-search').value);
    qsa('[data-map-project]').forEach(button => {
      const id = button.dataset.mapProject;
      button.hidden = !normalize(button.querySelector('strong').textContent).includes(term);
      button.querySelector('span').textContent = locations[id] ? `${locations[id].environment === 'city' ? 'Ciudad' : 'Campo'} · Ubicación confirmada` : 'Ubicación pendiente';
      button.setAttribute('aria-pressed',String(active === id));
      if (map && locations[id] && !button.hidden) {
        const record=locations[id];
        const project=projects.find(p=>p.id===id);
        const marker = L.marker([record.latitude,record.longitude], {icon:L.divIcon({className:'location-marker',html:'<span class="pin" aria-hidden="true"></span>',iconSize:[18,18],iconAnchor:[9,9]}),title:project.name,alt:project.name,keyboard:true});
        marker.bindPopup(popup(project)).on('click',()=>select(id,false)).addTo(layer);
        markers.set(id,marker);
      }
    });
    const otherList=qs('#map-other-projects');otherList.replaceChildren();
    for (const [id,record] of Object.entries(otherProjects)) {
      const button=document.createElement('button');button.type='button';button.className='map-project map-other-project';button.dataset.otherProject=id;
      button.hidden=!normalize('Otros proyectos '+record.name).includes(term);
      button.setAttribute('aria-pressed',String(active===id));
      const name=document.createElement('strong');name.textContent=otherName(record);
      const label=document.createElement('span');label.textContent=(record.name?'Otros proyectos · ':'')+(record.environment==='city'?'Ciudad':'Campo');
      button.append(name,label);button.addEventListener('click',()=>select(id));otherList.append(button);
      if (map && !button.hidden) {
        const title=['Otros proyectos',record.name].filter(Boolean).join(' · ');
        const marker=L.marker([record.latitude,record.longitude],{icon:L.divIcon({className:'location-marker',html:'<span class="pin other" aria-hidden="true"></span>',iconSize:[18,18],iconAnchor:[9,9]}),title,alt:title,keyboard:true});
        marker.bindPopup(otherPopup(record)).on('click',()=>select(id,false)).addTo(layer);markers.set(id,marker);
      }
    }
    const count=Object.keys(locations).length;
    const otherCount=Object.keys(otherProjects).length;
    qs('#map-status').textContent = count || otherCount ? `${count} ${count===1?'casa':'casas'} del portfolio y ${otherCount} ${otherCount===1?'otro proyecto':'otros proyectos'} con ubicación confirmada${storageAvailable && otherStorageAvailable ? '.' : '. Los cambios de esta visita no se guardan en el navegador; descargá una copia para conservarlos.'}` : 'Las obras aún no tienen ubicaciones confirmadas. Podés recorrer sus fichas y marcar los puntos en la revisión privada.';
    qs('#map-empty').hidden=qsa('[data-map-project],[data-other-project]').some(b=>!b.hidden);
  }
  function clearDraft() {
    if (draftMarker) { draftMarker.remove(); draftMarker=null; }
  }
  function updateBatch() {
    const count=batchPoints.length;
    qs('#location-batch-tools').hidden=!batchMode;
    qs('#location-batch-count').textContent=`${count} ${count===1?'punto sin guardar':'puntos sin guardar'}. Hacé clic en cada lugar; podés arrastrar los puntos para ajustarlos.`;
    qs('#location-batch-confirm').textContent=`Confirmar ${count} ${count===1?'punto':'puntos'}`;
    qs('#location-batch-confirm').disabled=!count;
    qs('#location-batch-undo').disabled=!count;
    ['#location-project','#location-confirm','#location-preview','#location-remove','#location-new-other','#location-batch-start','#location-lat','#location-lng','#location-import','#location-import-confirm','#location-mark-mode'].forEach(selector=>{qs(selector).disabled=batchMode;});
  }
  function clearBatch() {
    batchPoints.forEach(point=>point.marker.remove());batchPoints=[];batchMode=false;updateBatch();
  }
  function addBatchPoint(position) {
    const number=batchPoints.length+1;
    const point={position,marker:L.marker(position,{draggable:true,title:`Otros proyectos · Punto ${number} sin guardar`,alt:`Otros proyectos · Punto ${number} sin guardar`,icon:L.divIcon({className:'draft-marker',html:'<span class="pin other pending" aria-hidden="true"></span>',iconSize:[18,18],iconAnchor:[9,9]})}).addTo(map)};
    point.marker.on('dragend',()=>{const p=point.marker.getLatLng();point.position=[p.lat,p.lng];});
    batchPoints.push(point);updateBatch();
  }
  function confirmBatch() {
    if (!batchMode || !batchPoints.length) return;
    const environment=qs('#location-environment').value;
    if (!qs('#location-environment').reportValidity()) return;
    const name=qs('#location-other-name').value.trim();
    const count=batchPoints.length;
    if (batchPoints.some(point=>!valid({latitude:point.position[0],longitude:point.position[1],environment,verified:true}))) {status('Hay un punto fuera del rango de coordenadas válido. Ajustalo o descartá el lote antes de confirmar.');return;}
    for (const point of batchPoints) otherProjects[newOtherId()]={latitude:point.position[0],longitude:point.position[1],environment,verified:true,name};
    const saved=persistOther();clearBatch();active=null;render();loadFields('__other__');qs('#location-environment').value=environment;qs('#map-selected').hidden=true;
    status(`${count} ${count===1?'punto confirmado':'puntos confirmados'}${saved?' y guardados en este navegador.':' durante esta visita.'} Descargá una copia para conservarlos.`);
  }
  function loadFields(id) {
    clearDraft();
    editingOther=otherProjects[id] ? id : null;
    const isOther=id==='__other__' || !!editingOther;
    const record=isOther ? otherProjects[id] : locations[id];
    qs('#location-project').value=isOther ? '__other__' : id;
    qs('#location-other-fields').hidden=!isOther;
    qs('#location-other-name').value=isOther && record ? record.name : '';
    qs('#location-lat').value=record ? record.latitude : '';
    qs('#location-lng').value=record ? record.longitude : '';
    qs('#location-environment').value=record ? record.environment : '';
    qs('#location-mark-mode').checked=false;
  }
  function select(id,move=true) {
    if (batchMode) {status('Terminá de confirmar o descartar los puntos del lote antes de seleccionar otra obra.');return;}
    active=id;
    const project=projects.find(p=>p.id===id);
    const other=otherProjects[id];
    if (!project && !other) {qs('#map-selected').hidden=true;loadFields('__other__');return;}
    qs('#map-selected-title').textContent=other ? otherName(other) : project.name;
    qs('#map-selected-text').textContent=other ? 'Otros proyectos · Ubicación confirmada por el propietario.' : locations[id] ? `${project.title}. Ubicación confirmada por el propietario.` : `${project.title}. Ubicación pendiente de marcar.`;
    qs('#map-selected-link').hidden=!!other;
    if (project) qs('#map-selected-link').href=`obras/${id}.html`;
    qs('#map-selected').hidden=false;
    loadFields(id);
    qsa('[data-map-project],[data-other-project]').forEach(b=>b.setAttribute('aria-pressed',String((b.dataset.mapProject || b.dataset.otherProject)===id)));
    const record=other || locations[id];
    if (move && map && record) {
      map.setView([record.latitude,record.longitude],14,{animate:false});
      markers.get(id)?.openPopup();
    }
  }
  function coordinates() {
    const latText=qs('#location-lat').value.trim(),lngText=qs('#location-lng').value.trim();
    if (!latText || !lngText) return null;
    const latitude=Number(latText),longitude=Number(lngText);
    return Number.isFinite(latitude) && Math.abs(latitude)<=90 && Number.isFinite(longitude) && Math.abs(longitude)<=180 ? [latitude,longitude] : null;
  }
  function showDraft(position,move=false) {
    clearDraft();
    if (!map) return;
    draftMarker=L.marker(position,{draggable:true,title:'Punto en revisión; falta confirmar',alt:'Punto en revisión',icon:L.divIcon({className:'draft-marker',html:'<span class="pin draft" aria-hidden="true"></span>',iconSize:[18,18],iconAnchor:[9,9]})}).addTo(map);
    draftMarker.on('dragend',()=>{const p=draftMarker.getLatLng();qs('#location-lat').value=p.lat.toFixed(6);qs('#location-lng').value=p.lng.toFixed(6);status('Punto ajustado. Revisá el entorno y confirmá para guardarlo.');});
    if (move) map.setView(position,14,{animate:false});
  }
  if (window.L?.map) {
    map=L.map(canvas,{scrollWheelZoom:false,tap:false}).setView(views.city.center,views.city.zoom);
    const tiles=L.tileLayer('https://a.tile.opentopomap.org/{z}/{x}/{y}.png',{referrerPolicy:'strict-origin',maxZoom:17,attribution:'Datos: &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>, SRTM | Cartografía: &copy; <a href="https://opentopomap.org" target="_blank" rel="noopener noreferrer">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/" target="_blank" rel="noopener noreferrer">CC BY-SA</a>)'}).addTo(map);
    layer=L.layerGroup().addTo(map);
    let failures=0;
    tiles.on('tileerror',()=>{if(++failures>1){qs('#map-network-status').hidden=false;qs('#map-network-status').textContent='Parte de la cartografía no pudo cargarse. Las fichas y los controles de ubicación siguen disponibles.';}});
    map.on('click',event=>{
      if (!qs('.map-editor').open || !qs('#location-mark-mode').checked) return;
      if (batchMode) {addBatchPoint([event.latlng.lat,event.latlng.lng]);return;}
      qs('#location-lat').value=event.latlng.lat.toFixed(6);
      qs('#location-lng').value=event.latlng.lng.toFixed(6);
      showDraft([event.latlng.lat,event.latlng.lng]);
      status('Punto marcado para revisión. Elegí el entorno y confirmá para guardarlo.');
    });
  } else {
    canvas.textContent='El mapa no pudo cargarse. Podés recorrer las fichas y registrar coordenadas con los controles de revisión.';
  }
  qsa('[data-map-project]').forEach(button=>button.addEventListener('click',()=>select(button.dataset.mapProject)));
  qs('#map-search').addEventListener('input',render);
  qsa('[data-map-view]').forEach(button=>button.addEventListener('click',()=>{
    const v=views[button.dataset.mapView];map?.setView(v.center,v.zoom,{animate:false});
    qsa('[data-map-view]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
  }));
  qs('#map-reset').addEventListener('click',()=>{
    map?.setView(views.city.center,views.city.zoom,{animate:false});map?.closePopup();
    qsa('[data-map-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mapView==='city')));
  });
  qs('#location-project').addEventListener('change',event=>{loadFields(event.target.value);status(event.target.value==='__other__'?'Marcá un nuevo punto de Otros proyectos y confirmá para guardarlo.':'Elegí el punto de esta obra. Todavía no se guardó ningún cambio.');});
  qs('#location-new-other').addEventListener('click',()=>{loadFields('__other__');qs('#location-mark-mode').checked=true;status('Marcá el nuevo punto de Otros proyectos en el mapa y confirmá su ubicación.');});
  qs('#location-batch-start').addEventListener('click',()=>{
    if (!map) {status('El mapa debe estar disponible para marcar varios puntos.');return;}
    if (!qs('#location-environment').reportValidity()) {status('Elegí Ciudad o Campo y alrededores antes de marcar el lote.');return;}
    const environment=qs('#location-environment').value,name=qs('#location-other-name').value;
    loadFields('__other__');qs('#location-environment').value=environment;qs('#location-other-name').value=name;
    batchMode=true;qs('#location-mark-mode').checked=true;updateBatch();map.closePopup();
    status('Hacé clic en los distintos lugares. Al terminar, confirmá todos los puntos con el botón sobre el mapa.');
    canvas.scrollIntoView({block:'center'});
  });
  qs('#location-batch-confirm').addEventListener('click',confirmBatch);
  qs('#location-batch-undo').addEventListener('click',()=>{batchPoints.pop()?.marker.remove();updateBatch();});
  qs('#location-batch-cancel').addEventListener('click',()=>{clearBatch();loadFields('__other__');status('Lote descartado. Las ubicaciones guardadas se conservan.');});
  qs('#location-preview').addEventListener('click',()=>{
    const position=coordinates();
    if (!position){status('Ingresá latitud y longitud válidas, o marcá el punto en el mapa.');return;}
    showDraft(position,true);status('Punto en revisión. La ubicación se guarda al confirmar.');
  });
  qs('#location-cancel').addEventListener('click',()=>{if(batchMode)clearBatch();loadFields(editingOther || qs('#location-project').value);status('Cambio descartado. Se conserva la última ubicación confirmada.');});
  qs('#location-form').addEventListener('submit',event=>{
    event.preventDefault();
    if (batchMode) {confirmBatch();return;}
    const form=event.currentTarget;
    if (!form.reportValidity()) return;
    const position=coordinates();if(!position){status('Las coordenadas no son válidas.');return;}
    const isOther=qs('#location-project').value==='__other__';
    const id=isOther ? editingOther || newOtherId() : qs('#location-project').value;
    const record={latitude:position[0],longitude:position[1],environment:qs('#location-environment').value,verified:true};
    if (isOther) otherProjects[id]={...record,name:qs('#location-other-name').value.trim()};
    else locations[id]=record;
    const saved=isOther ? persistOther() : persist();clearDraft();render();select(id,false);
    status(saved?'Ubicación confirmada y guardada en este navegador. Descargá una copia para conservarla.':'Ubicación confirmada durante esta visita. El navegador no permitió guardarla: descargá una copia.');
  });
  qs('#location-remove').addEventListener('click',()=>{
    if (qs('#location-project').value==='__other__') {
      if (!editingOther) {status('Marcá y confirmá el punto antes de quitarlo.');return;}
      delete otherProjects[editingOther];const saved=persistOther();active=null;render();loadFields('__other__');qs('#map-selected').hidden=true;
      status(saved?'Punto de Otros proyectos quitado. Las casas del portfolio se conservan.':'Punto quitado durante esta visita. Descargá la copia actualizada.');return;
    }
    const id=qs('#location-project').value;
    if (!locations[id]) {status('Esta obra todavía no tiene una ubicación confirmada.');return;}
    delete locations[id];const saved=persist();clearDraft();render();loadFields(id);
    if(active===id) select(id,false);
    status(saved?'Ubicación quitada. La obra vuelve a quedar pendiente.':'Ubicación quitada durante esta visita. Descargá la copia actualizada.');
  });
  const backupTools = qs('#location-export').parentElement;
  const showBackup = document.createElement('button');
  showBackup.type='button';showBackup.className='button secondary';showBackup.textContent='Ver y copiar ubicaciones';
  const backupPanel=document.createElement('div');backupPanel.hidden=true;
  const backupLabel=document.createElement('label');backupLabel.htmlFor='location-backup-text';backupLabel.textContent='Copia de tus ubicaciones';
  const backupCount=document.createElement('p');backupCount.className='small';backupCount.setAttribute('role','status');
  const backupText=document.createElement('textarea');backupText.id='location-backup-text';backupText.readOnly=true;backupText.rows=10;backupText.style.width='100%';backupText.style.boxSizing='border-box';
  const copyBackup=document.createElement('button');copyBackup.type='button';copyBackup.className='button secondary';copyBackup.textContent='Copiar ubicaciones';
  backupPanel.append(backupLabel,backupCount,backupText,copyBackup);backupTools.append(showBackup,backupPanel);
  function showBackupText(){
    backupText.value=JSON.stringify({version:2,locations,otherProjects},null,2);
    const houses=Object.keys(locations).length,others=Object.keys(otherProjects).length;
    backupCount.textContent=houses||others?`${houses} casas y ${others} otros proyectos. Copiá este texto y pegalo en la conversación para incorporarlo a la web.`:'No hay puntos guardados en este navegador. Abrí el mapa en el navegador donde los marcaste.';
    backupPanel.hidden=false;
    return backupText.value;
  }
  showBackup.addEventListener('click',()=>{showBackupText();backupText.focus();backupText.select();});
  copyBackup.addEventListener('click',async()=>{
    const data=showBackupText();backupText.focus();backupText.select();
    try {await navigator.clipboard.writeText(data);status('Ubicaciones copiadas. Pegalas en la conversación.');}
    catch {status('El texto está seleccionado. Presioná Ctrl+C (o Cmd+C) y pegalo en la conversación.');}
  });
  qs('#location-export').addEventListener('click',()=>{
    const data=showBackupText();
    try {
      const url=URL.createObjectURL(new Blob([data],{type:'application/json'}));
      const a=document.createElement('a');a.href=url;a.download='gd-ubicaciones.json';document.body.append(a);a.click();a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),60000);
      status('Se solicitó la descarga. Si no aparece el archivo, usá «Copiar ubicaciones» debajo y pegá el texto en la conversación.');
    } catch {status('No se pudo iniciar la descarga. Usá «Copiar ubicaciones» debajo y pegá el texto en la conversación.');}
  });
  qs('#location-import').addEventListener('change',async event=>{
    importDraft=null;qs('#location-import-confirm').hidden=true;
    const file=event.target.files?.[0];if(!file)return;
    if(file.size>1000000){status('La copia es demasiado grande. Elegí el archivo JSON de ubicaciones de GD.');return;}
    try {importDraft=decodeBackup(JSON.parse(await file.text()));const count=Object.keys(importDraft.locations).length;qs('#location-import-confirm').hidden=false;status(`Copia válida con ${count} ${count===1?'casa':'casas'}${importDraft.otherProjects===null ? '. Los otros proyectos se conservarán' : ' y '+Object.keys(importDraft.otherProjects).length+' otros proyectos'}. Confirmá para recuperar esta copia.`);}
    catch(error){status(error instanceof SyntaxError?'El archivo no contiene JSON válido.':error.message);}
  });
  qs('#location-import-confirm').addEventListener('click',()=>{
    if(!importDraft)return;
    locations=importDraft.locations;
    const hasOthers=importDraft.otherProjects!==null;
    if (hasOthers) otherProjects=importDraft.otherProjects;
    importDraft=null;const mainSaved=persist();const othersSaved=hasOthers ? persistOther() : true;const saved=mainSaved && othersSaved;clearDraft();render();loadFields(qs('#location-project').value);
    qs('#location-import-confirm').hidden=true;qs('#location-import').value='';
    if(active)select(active,false);
    status(saved?'Copia recuperada y guardada en este navegador.':'Copia recuperada durante esta visita. El navegador no permitió guardarla.');
  });
  window.addEventListener('storage',event=>{
    if(![key,otherKey].includes(event.key))return;
    try {
      if (event.key===key) locations=event.newValue?decode(JSON.parse(event.newValue)):{};
      else {const data=event.newValue?JSON.parse(event.newValue):{version:1,otherProjects:{}};if(data.version!==1)throw new Error('Version');otherProjects=decodeOther(data.otherProjects);}
      clearDraft();render();if(!batchMode){if(active)select(active,false);else loadFields(qs('#location-project').value);}status('Ubicaciones actualizadas desde otra pestaña.');
    }
    catch {status('No se pudo leer el cambio de otra pestaña. Se conservan los puntos de esta visita.');}
  });
  render();
  loadFields(qs('#location-project').value);
})();
