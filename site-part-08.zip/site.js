(() => {
  'use strict';
  const qs = (s, root = document) => root.querySelector(s);
  const qsa = (s, root = document) => [...root.querySelectorAll(s)];
  const normalize = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

  const menuButton = qs('.menu-toggle');
  const nav = qs('#site-nav');
  const projectsToggle = qs('#projects-toggle');
  const projectsMenu = qs('#projects-menu');
  const setProjects = open => {
    if (!projectsToggle || !projectsMenu) return;
    projectsToggle.setAttribute('aria-expanded', String(open));
    projectsMenu.hidden = !open;
  };
  const setMenu = open => {
    nav?.classList.toggle('is-open', open);
    menuButton?.setAttribute('aria-expanded', String(open));
    if (menuButton) menuButton.textContent = open ? 'Cerrar' : 'Menú';
    if (!open) setProjects(false);
  };
  menuButton?.addEventListener('click', () => setMenu(menuButton.getAttribute('aria-expanded') !== 'true'));
  projectsToggle?.addEventListener('click', () => setProjects(projectsToggle.getAttribute('aria-expanded') !== 'true'));
  qsa('.nav a').forEach(link => link.addEventListener('click', () => setMenu(false)));
  document.addEventListener('click', event => {
    if (!event.target.closest('.project-disclosure')) setProjects(false);
  });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    if (projectsToggle?.getAttribute('aria-expanded') === 'true') {
      setProjects(false); projectsToggle.focus();
    } else if (menuButton?.getAttribute('aria-expanded') === 'true') {
      setMenu(false); menuButton.focus();
    }
  });

  const hero = qs('.hero-carousel');
  if (hero) {
    const slides = qsa('[data-slide]',hero);
    const selector = qs('#hero-select');
    let current = 0, request = 0, start = null;
    const renderSlide = async index => {
      const next = (index + slides.length) % slides.length;
      const token = ++request;
      const img = qs('img',slides[next]);
      img.loading = 'eager';
      try { if (img.decode) await img.decode(); } catch { /* Keep alt text when an asset cannot load. */ }
      if (token !== request) return;
      current = next;
      slides.forEach((slide,i) => {
        slide.hidden = i !== current;
        slide.classList.toggle('is-entering',i===current);
      });
      selector.value = String(current);
      qs('#hero-description').textContent = slides[current].dataset.description;
      qs('#hero-counter').textContent = `${String(current+1).padStart(2,'0')} / ${slides.length}`;
      const upcoming = qs('img',slides[(current+1)%slides.length]);
      upcoming.loading = 'eager';
    };
    qs('#hero-prev').addEventListener('click',()=>renderSlide(current-1));
    qs('#hero-next').addEventListener('click',()=>renderSlide(current+1));
    selector.addEventListener('change',()=>renderSlide(Number(selector.value)));
    qs('#hero-slides').addEventListener('keydown',event=>{
      const actions={ArrowLeft:current-1,ArrowRight:current+1,Home:0,End:slides.length-1};
      if(event.key in actions){event.preventDefault();renderSlide(actions[event.key]);}
    });
    const stage=qs('#hero-slides');
    stage.addEventListener('touchstart',event=>{if(event.touches.length===1)start={x:event.touches[0].clientX,y:event.touches[0].clientY};},{passive:true});
    stage.addEventListener('touchend',event=>{
      if(!start || !event.changedTouches.length)return;
      const dx=event.changedTouches[0].clientX-start.x,dy=event.changedTouches[0].clientY-start.y;
      start=null;
      if(Math.abs(dx)>45 && Math.abs(dx)>Math.abs(dy)*1.3)renderSlide(current+(dx<0?1:-1));
    },{passive:true});
    stage.addEventListener('touchcancel',()=>{start=null;},{passive:true});
    if(slides[1])qs('img',slides[1]).loading='eager';
  }

  const cards = qsa('.project-card');
  if (cards.length && qs('#project-search')) {
    const filters = qsa('[data-filter]');
    const search = qs('#project-search');
    const more = qs('#show-more');
    let filter = 'all', expanded = false;
    const render = () => {
      const term = normalize(search.value);
      const matches = cards.filter(card => (filter === 'all' || card.dataset.tags.split(' ').includes(filter)) && normalize(card.dataset.search).includes(term));
      const limited = filter === 'all' && !term && !expanded && !qs('[data-full-archive]');
      cards.forEach(card => { card.hidden = !matches.includes(card) || (limited && matches.indexOf(card) >= 6); });
      const shown = cards.filter(card => !card.hidden).length;
      qs('#portfolio-count').textContent = shown === matches.length ? `${matches.length} ${matches.length === 1 ? 'obra' : 'obras'} del archivo` : `${shown} de ${matches.length} obras del archivo`;
      qs('#portfolio-empty').hidden = matches.length > 0;
      more.hidden = !limited || matches.length <= 6;
      filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.filter === filter)));
    };
    filters.forEach(button => button.addEventListener('click', () => { filter = button.dataset.filter; expanded = false; render(); }));
    search.addEventListener('input', () => { expanded = false; render(); });
    more.addEventListener('click', () => { expanded = true; render(); });
    qs('#clear-filters').addEventListener('click', () => { filter = 'all'; expanded = true; search.value = ''; render(); search.focus(); });
    render();
  }

  const tabs = qsa('.process-tab');
  const selectTab = tab => {
    tabs.forEach(button => {
      const selected = button === tab;
      button.setAttribute('aria-selected', String(selected));
      button.tabIndex = selected ? 0 : -1;
      const panel = document.getElementById(button.getAttribute('aria-controls'));
      if (panel) panel.hidden = !selected;
    });
  };
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectTab(tab));
    tab.addEventListener('keydown', event => {
      let next = null;
      if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
      if (event.key === 'ArrowLeft') next = (index + tabs.length - 1) % tabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = tabs.length - 1;
      if (next !== null) { event.preventDefault(); selectTab(tabs[next]); tabs[next].focus(); }
    });
  });

  const form = qs('#contact-form');
  if (form) {
    let draft = '';
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      const name = qs('#contact-name').value.trim();
      const place = qs('#contact-place').value.trim();
      const story = qs('#contact-story').value.trim();
      qs('#contact-name').setCustomValidity(name ? '' : 'Completá tu nombre.');
      qs('#contact-story').setCustomValidity(story ? '' : 'Contanos tu idea para preparar el mensaje.');
      if (!name || !story) { form.reportValidity(); return; }
      draft = `Hola GD, soy ${name}.\n\nMe gustaría conversar sobre mi casa.${place ? `\nLugar: ${place}.` : ''}\n\n${story}`;
      qs('#draft-text').textContent = draft;
      qs('#draft-whatsapp').href = `https://wa.me/5492494626455?text=${encodeURIComponent(draft)}`;
      qs('#draft-email').href = `mailto:rgarciareid@gmail.com?subject=${encodeURIComponent('Mi proyecto de casa · ' + name)}&body=${encodeURIComponent(draft)}`;
      qs('#draft-status').textContent = '';
      qs('#draft-panel').hidden = false;
    });
    form.addEventListener('input', event => { event.target.setCustomValidity?.(''); qs('#draft-panel').hidden = true; });
    qs('#draft-copy').addEventListener('click', async () => {
      try {
        if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
        await navigator.clipboard.writeText(draft);
        qs('#draft-status').textContent = 'Mensaje copiado.';
      } catch {
        const range = document.createRange();
        range.selectNodeContents(qs('#draft-text'));
        const selection = window.getSelection();
        selection.removeAllRanges(); selection.addRange(range);
        qs('#draft-status').textContent = 'El texto está seleccionado. Copialo para usarlo en tu mensaje.';
      }
    });
  }

  const detail = qs('[data-detail]');
  const lightbox = qs('#lightbox');
  if (detail && lightbox) {
    const project = (window.GD_PROJECTS || []).find(p => p.id === detail.dataset.detail);
    if (!project) return;
    let current = 0, trigger = null;
    const renderImage = () => {
      const item = project.images[current];
      qs('#lightbox-image').src = document.body.dataset.root + item.src;
      qs('#lightbox-image').alt = item.alt;
      qs('#lightbox-caption').textContent = item.alt;
      qs('#lightbox-counter').textContent = `${current + 1} / ${project.images.length}`;
    };
    const change = delta => { current = (current + delta + project.images.length) % project.images.length; renderImage(); };
    qsa('[data-gallery]').forEach(button => button.addEventListener('click', () => {
      current = Number(button.dataset.gallery); trigger = button; renderImage();
      if (typeof lightbox.showModal === 'function') { lightbox.showModal(); document.body.style.overflow = 'hidden'; qs('#lightbox-close').focus(); }
      else window.location.assign(document.body.dataset.root + project.images[current].src);
    }));
    qs('#lightbox-close').addEventListener('click', () => lightbox.close());
    qs('#lightbox-prev').addEventListener('click', () => change(-1));
    qs('#lightbox-next').addEventListener('click', () => change(1));
    lightbox.addEventListener('keydown', event => {
      if (event.key === 'ArrowLeft') { event.preventDefault(); change(-1); }
      if (event.key === 'ArrowRight') { event.preventDefault(); change(1); }
    });
    lightbox.addEventListener('click', event => { if (event.target === lightbox) lightbox.close(); });
    lightbox.addEventListener('close', () => { document.body.style.overflow = ''; trigger?.focus(); });
  }
})();
